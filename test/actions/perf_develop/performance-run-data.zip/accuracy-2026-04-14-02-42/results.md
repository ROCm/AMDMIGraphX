<br /><summary>&nbsp;&nbsp;&nbsp;&nbsp; :white_check_mark: resnet50v1: PASSED: MIGraphX meets tolerance</summary>
